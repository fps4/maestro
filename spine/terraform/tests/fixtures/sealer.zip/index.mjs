export const handler = async () => ({ stub: true });
